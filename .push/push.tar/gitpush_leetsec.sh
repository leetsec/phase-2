#!/bin/sh
TOKEN1="ghp_967ck"
TOKEN2="H4Fq4YR4E"
TOKEN3="H1BlUkrBh"
TOKEN4="XCXH9Aw1H"
TOKEN5="xwMj"
#TOKEN="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"
if [ $# -eq 0 ]
then
	echo "Not enough arguments, usage : ./gitpush '<commit comments>'"
	exit
else

	git config pull.rebase false
	git pull https://leetsec:$TOKEN1$TOKEN2$TOKEN3$TOKEN4$TOKEN5@github.com/leetsec/phase-2.git
	#git pull
	#git add wordpress-hack network-hack -u -except gitpush_leetsec.sh admin #Just in case your gitpush file is in the git folder
	git add . -u -except gitpush_leetsec.sh -u -except .push -u -except push.sh
	#git reset -- gitpush_leetsec.sh
	#git reset -- .push/
	git commit -m "$1"
	git pull https://leetsec:$TOKEN1$TOKEN2$TOKEN3$TOKEN4$TOKEN5@github.com/leetsec/phase-2.git
	git push https://leetsec:$TOKEN1$TOKEN2$TOKEN3$TOKEN4$TOKEN5@github.com/leetsec/phase-2.git
	git pull https://leetsec:$TOKEN1$TOKEN2$TOKEN3$TOKEN4$TOKEN5@github.com/leetsec/phase-2.git
	#repeating git push & pull just in case someone is pushing at the same time with a lot of different local change for different machine it can caused problem 
	git push https://leetsec:$TOKEN1$TOKEN2$TOKEN3$TOKEN4$TOKEN5@github.com/leetsec/phase-2.git
	git pull https://leetsec:$TOKEN1$TOKEN2$TOKEN3$TOKEN4$TOKEN5@github.com/leetsec/phase-2.git
fi
